package phase1.modifier;
class defAccessSpecifier
{ 
  void display() 
     { 
         System.out.println("You are using defalut access modifier"); 
     } 
} 
public class accessmodifier {
	public static void main(String[] args) {
		//default
		System.out.println("Dafault Access modifier");
		defAccessSpecifier obj = new defAccessSpecifier(); 		  
        obj.display(); 

	}
}