package phase1;
import java.util.*;

import java.util.Map.Entry;

public class map {
	public static void main(String args[]) {

		Map<Integer, String> map = new HashMap<Integer, String>();

		map.put(1, "football");

		map.put(2, "Tennis");

		map.put(3, "cricket");

		for (Iterator<Entry<Integer, String>> iterator = map.entrySet().iterator(); iterator.hasNext();) {

		Entry<Integer, String> m = iterator.next();

		System.out.println(m.getKey() + " " + m.getValue());

		}

		}
}
