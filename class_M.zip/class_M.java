package phase1;

public class class_M {
private int a=20;
long b=100;
protected float c=20.89f;
public void methodPublic()
{
	System.out.println("We are in M class Public method");
	methodPrivate();
	}
protected void methodProtected(){
	System.out.println("We are M class protected method");
	methodPrivate();
}
void methodDefault()
{
	System.out.println("We are in M class Default method");
	methodPrivate();
	
}
private void methodPrivate()
{
	System.out.println("Class M");
	System.out.println("value of private:"+a);
	System.out.println("value of long:"+b);
	System.out.println("value of float:"+c);
	
}
}
