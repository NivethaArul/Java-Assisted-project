package phase1.modifier;

public class class_N {
	protected long d=6345;
	public int e=20;
	double f=24.78;
	public void methodPublic()
	{
		System.out.println("We are in M class Public method");
		methodPrivate();
	}
	protected void methodProtected()
	{
		System.out.println("We are in M class protected method");
		methodPrivate();
	}
	void methodDefault()
	{
		System.out.println("We are in M class Default method");
		methodPrivate();
	}
		private void methodPrivate()
		{
			System.out.println("class M");
			System.out.println("Value of long:+d");
			System.out.println("Value of int:"+e);
			System.out.println("Value of double:+f");
		}
	}


