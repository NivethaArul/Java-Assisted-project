package phase1;

public class innerclass {
 private String msg="Welcome to mphasis"; 
	 
	 class Inner{  
	  void hello(){System.out.println(msg+", let us starting the program");}  
	 }  


	public static void main(String[] args) {

		innerclass obj=new innerclass();
		innerclass.Inner in=obj.new Inner();  
		in.hello();  
	}
}



