package phase1;
import java.util.ArrayList;
import java.util.regex.*;
public class Regulexpression {
	public static void main(String args[]) {
		ArrayList<String> emails = new ArrayList<String>();
		emails.add("akshaya.xyz@gmail.com");
		emails.add("aagalaiya.new@gmail.com");
		String regex = "^(.+)@(.+)$";
		Pattern pattern = Pattern.compile(regex);
		for(String email : emails) {
			Matcher matcher = pattern.matcher(email);
			System.out.println(email +" : "+ matcher.matches()+"\n");
		}
	}

}