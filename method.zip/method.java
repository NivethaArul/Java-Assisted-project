package phase1;

public class method {
	public int addNumbers(int x, int y){
		int addition = x+y;
		return addition;
		}
	public static void main(String args[]) {
		int a = 12;
		int b = 59;
		method obj = new method();
		int result = obj.addNumbers(a,b);
		System.out.println("Sum of a+b = " + result);
	}

}
